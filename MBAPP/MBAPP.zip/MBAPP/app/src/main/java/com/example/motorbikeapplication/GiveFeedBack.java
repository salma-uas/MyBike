package com.example.motorbikeapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class GiveFeedBack extends AppCompatActivity {
  private ImageView imageView;
  private Button getmbutton;
  private Button getmReportAnIssue;
  private TextView MohammadFarhanBinBMW007;
  private TextView FareRm10;
  private TextView personalTrip;
 private   TextView IuklBlockA;
  private TextView SerdangKTMGateA;
 private   TextView BookingIdAD123456;
 private   TextView Rating;
    Button mConfirm;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_give_feed_back);
        mConfirm = (Button) findViewById(R.id.Submit);


     mConfirm.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent digitalreceiptIntent = new Intent (GiveFeedBack.this,AssistanceCentre.class
            );
            startActivity(digitalreceiptIntent);

        }
    });
}
}
