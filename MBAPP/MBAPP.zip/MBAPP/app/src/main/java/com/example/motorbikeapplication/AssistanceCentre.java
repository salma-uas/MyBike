package com.example.motorbikeapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class AssistanceCentre extends AppCompatActivity {

    ImageView imageView;
    private EditText hondaBike;
    private EditText PlateNumberBx390;
    private EditText Completed03Aug20190423PM;
    private EditText IUKLBlockAto;
    private EditText SerdangKtmGateA;
    private EditText FareRm10;
    private EditText ReportAnIssue;
    private EditText AccidentAndSafety;
    private EditText IleftmybagintheMotorBike;
    private EditText Ipaidmore;
//    private EditText Drivernotgivenmechange.;
//    private EditText DriverChrgememorethanfare.;
    private EditText Igavewrongamount;
    private EditText SexuallyHarassment;
//    private EditText Send email:Iukl@pickupfirst.edu.my;
//    private EditText Callusto:0384756309;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assistance_centre);




//        mConfirm.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent givefeedbackIntent = new Intent (AssistanceCentre.this,GiveFeedBack.class
//                );
//                startActivity(givefeedbackIntent);
//
//            }
//        });





    }
}
