package com.example.motorbikeapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class BookingPageContinue2 extends AppCompatActivity {
    ImageView imageView;
    Button ChangeDropLocation;
    Button Cancel;
    Spinner spinner, spinner1;
    TextView price;
    ArrayAdapter<CharSequence> adapter;
    Button mConfirm;
    int destination,location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_page_continue2);
        spinner = (Spinner)findViewById(R.id.spinner);
        spinner1 = (Spinner)findViewById(R.id.spinner1);

        price = findViewById(R.id.price);
        adapter=ArrayAdapter.createFromResource(this,R.array.SelectLocation_names,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner1.setAdapter(adapter);
        mConfirm = (Button) findViewById(R.id.Button2);




        mConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent BookingPageContinue= new Intent (BookingPageContinue2.this,BookingPageContinue3.class
                );
                startActivity(BookingPageContinue);

            }
        });
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                int location = spinner1.getSelectedItemPosition();
                int destination = spinner.getSelectedItemPosition();
                if(location == 0 && destination == 0){
                    price.setText("RM8");
                }
                else if(location == 0 && destination == 1){
                    price.setText("RM13");
                }
                else if(location == 0 && destination == 2){
                    price.setText("RM13");
                }
                else if(location == 0 && destination == 3){
                    price.setText("RM16");
                }
                else if(location == 0 && destination == 4){
                    price.setText("RM5");
                }
                else if(location == 0 && destination == 5){
                    price.setText("RM18");
                }
                else if(location == 0 && destination == 6){
                    price.setText("RM17");
                }

                else if(location == 0 && destination == 7){
                    price.setText("RM9");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {

                location = spinner1.getSelectedItemPosition();
                destination = spinner.getSelectedItemPosition();
                if(location == 0 && destination == 0){
                    price.setText("RM8");
                }
                if(location == 0 && destination == 0){
                    price.setText("RM8");
                }
                else if(location == 0 && destination == 1){
                    price.setText("RM13");
                }
                else if(location == 0 && destination == 2){
                    price.setText("RM13");
                }
                else if(location == 0 && destination == 3){
                    price.setText("RM16");
                }
                else if(location == 0 && destination == 4){
                    price.setText("RM5");
                }
                else if(location == 0 && destination == 5){
                    price.setText("RM18");
                }
                else if(location == 0 && destination == 6){
                    price.setText("RM17");
                }

                else if(location == 0 && destination == 7){
                    price.setText("RM9");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

    }
}