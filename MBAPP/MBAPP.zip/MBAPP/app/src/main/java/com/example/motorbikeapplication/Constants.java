package com.example.motorbikeapplication;

public class Constants {
   public static final String ROOT_URL="http://192.168.0.112/mbapp/v1/";
   public static final String ROOT_URL_IMAGE="http://192.168.0.112/mbapp/image/passenger/";

   public static final String URL_REGISTER = ROOT_URL+"passenger_register.php";
   public static final String URL_LOGIN = ROOT_URL+"userLogin.php";
   public static final String URL_MAKE_BOOKING = ROOT_URL+"booking_create.php";
   public static final String URL_UPDATE_BOOKING= ROOT_URL+"booking_update.php";
   public static final String URL_DIGITAL_RECEIPT= ROOT_URL+"booking_digital_receipt.php?book_id=";
   public static final String URL_GIVE_RATING= ROOT_URL+"booking_give_rating.php";
   public static final String URL_VIEW_PROFILE = ROOT_URL+"passenger_view.php?id=";
   public static final String URL_UPDATE_PROFILE= ROOT_URL+"passenger_update.php";
   public static final String URL_PREVIOUS_TRIP= ROOT_URL+"booking_get_previous_trip.php?user_id=";




//   public static final String URL_GET_CUURENT_BOOKING = ROOT_URL+"booking_get_current.php";




}
