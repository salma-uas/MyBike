package com.example.motorbikeapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.os.CountDownTimer;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class BookingPageContinue extends AppCompatActivity {
    Button btnPayment, btnFeedback, btnCancel, btnArrived, btnCompleted;

    Spinner spinner, spinner1;
    TextView txtPickupPointValue, txtDestinationtValue,txtPriceValue, txtStatus, txtBookingIDValue, txtTimer;
    ArrayAdapter<CharSequence> adapter;
    int destination,location, counter_min = 2 ,counter = 60;
    private boolean timerRunning;
    private CountDownTimer countDownTimer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_page_continue);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Make Booking");

        SharedPrefManager sharedPrefManager = SharedPrefManager.getInstance(this);

        int booking_id = sharedPrefManager.getBookingId();
        String location = sharedPrefManager.getLocations();
        String destination = sharedPrefManager.getDestination();
        String status = sharedPrefManager.getStatus();
        String price = sharedPrefManager.getPrice();

        txtPickupPointValue = findViewById(R.id.txtPickupPointValue);
        txtDestinationtValue = findViewById(R.id.txtDestinationtValue);
        txtPriceValue = findViewById(R.id.txtPriceValue);
        txtStatus = findViewById(R.id.txtStatus);
        txtBookingIDValue = findViewById(R.id.txtBookingIDValue);
        txtTimer = findViewById(R.id.txtTimer);

        if (SharedPrefManager.getInstance(BookingPageContinue.this).isTimer()){

            int min = sharedPrefManager.getMin();
            int sec = sharedPrefManager.getSec();

            counter_min = min;
            counter = sec;

        }

        countDownTimer  = new CountDownTimer(120000, 1000){
            @Override
            public void onTick(long l) {

                txtTimer.setText(String.valueOf("You can only cancel this booking within\n" + counter_min + ":" +counter));
//                updateTimer();

                if(counter == 0 && counter_min == 0){
                    counter_min = 0;
                    counter = 0;
                }
                else if( counter == 0)
                {
                    counter_min--;
                    counter = 60;

                }
                counter--;

                SharedPrefManager.getInstance(getApplicationContext()).setTimer(counter_min,counter);
//
//                counter = 1;
//                updateTimer();

            }

            @Override
            public void onFinish() {

                txtTimer.setText("You cannot cancel this booking");
                btnCancel.setVisibility(View.INVISIBLE);


            }
        }.start();
//
//        timerRunning = true;

        txtBookingIDValue.setText(String.valueOf(booking_id));
        txtPickupPointValue.setText(location);
        txtDestinationtValue.setText(destination);
        txtPriceValue.setText(price);

        btnPayment = (Button) findViewById(R.id.btnPayment);
        btnFeedback = (Button) findViewById(R.id.btnFeedback);
        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnArrived = (Button) findViewById(R.id.btnArrived);
        btnCompleted = (Button) findViewById(R.id.btnCompleted);



        btnPayment.setVisibility(View.INVISIBLE);
        btnFeedback.setVisibility(View.INVISIBLE);
        btnCompleted.setVisibility(View.INVISIBLE);



//
//        if(status == "pending"){
//            txtStatus.setText("Driver on the way");
//        }else{
//            txtStatus.setText("Driver on the way");
//
//        }



    }

//    public void updateTimer(){
//
//        int minutes = (int) counter / 60000;
//        int seconds = (int) counter % 60000 / 1000;
//
//        String timeleftText;
//
//        timeleftText = "" + minutes;
//        timeleftText += ":";
//
//        if(seconds < 10) timeleftText += "0";
//        timeleftText += seconds;
//
//        txtTimer.setText(timeleftText);
//    }


    public void onCancelBooking(View view){

        SharedPrefManager sharedPrefManager = SharedPrefManager.getInstance(this);
        int booking_id = sharedPrefManager.getBookingId();

        updateBooking(booking_id, "Cancelled");

        sharedPrefManager.removeCurrentBooking();


    }

    public void onArrived(View view){

        SharedPrefManager sharedPrefManager = SharedPrefManager.getInstance(this);
        int booking_id = sharedPrefManager.getBookingId();

        updateBooking(booking_id, "in-progress");

        txtStatus.setText("Heading to your destination");

        btnCompleted.setVisibility(View.VISIBLE);


        btnCancel.setVisibility(View.INVISIBLE);
        btnArrived.setVisibility(View.INVISIBLE);


    }

    public void onPayment(View view){

        SharedPrefManager sharedPrefManager = SharedPrefManager.getInstance(this);
        int booking_id = sharedPrefManager.getBookingId();

        Intent mainPage = new Intent(BookingPageContinue.this, DigitalReceipt.class);
        mainPage.putExtra("booking_id", booking_id);
        startActivity(mainPage);
    }

    public void onFeedback(View view){

        Intent mainPage = new Intent(BookingPageContinue.this, GiveFeedBack.class);
        startActivity(mainPage);
    }

    public void onCompleted(View view){

        SharedPrefManager sharedPrefManager = SharedPrefManager.getInstance(this);
        int booking_id = sharedPrefManager.getBookingId();

        updateBooking(booking_id, "completed");

        txtStatus.setText("Safely arrived at your destination");



        btnCompleted.setVisibility(View.INVISIBLE);

        btnPayment.setVisibility(View.VISIBLE);
        btnFeedback.setVisibility(View.VISIBLE);


        Intent mainPage = new Intent(BookingPageContinue.this, DigitalReceipt.class);
        mainPage.putExtra("booking_id", booking_id);
        startActivity(mainPage);

        finish();
        sharedPrefManager.removeCurrentBooking();


    }








    private void updateBooking(final int booking_id, final String status) {


        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_UPDATE_BOOKING,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject =  new JSONObject(response);

                            if(!jsonObject.getBoolean("error")){

                                Toast.makeText(getApplicationContext(), "Booking " + status, Toast.LENGTH_LONG).show();

                                if(status == "cancelled"){
                                    finish();

                                    Intent mainPage = new Intent(BookingPageContinue.this, BookingPage.class);
                                    startActivity(mainPage);

                                }
//                                else if(status == "in-progress"){
//                                    Intent mainPage = new Intent(BookingPageContinue.this, BookingPageContinue2.class);
//                                    startActivity(mainPage);
//
//                                }

                            }
                            else{
                                Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_LONG).show();

                            }

                        } catch (JSONException e){
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //     Toast.makeText(getApplicationContext(), "E-mail: admin@andkl.com.my\nPassword: admin123", Toast.LENGTH_LONG).show();
                        Toast.makeText(getApplicationContext(), "Wrong IP entered", Toast.LENGTH_LONG).show();
                        //      Toast.makeText(LoginActivity.this, "Failed to retrieve data", Toast.LENGTH_LONG).show();

                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("booking_id", String.valueOf(booking_id));
                params.put("status", status);
//                params.put("access", "user");

                return params;
            }
        };


        Volley.newRequestQueue(this).add(stringRequest);
    }


//    private void loadCurrentBooking(int group_id)
//    {
//
////        SharedPrefManager sharedPrefManager = SharedPrefManager.getInstance(this);
////        final String ipaddress = sharedPrefManager.getIP();
//
//        StringRequest stringRequest = new StringRequest(com.android.volley.Request.Method.GET, IPAddress.ROOT_HTTP + ipaddress + IPAddress.ROOT_FOLDER + IPAddress.URL_GET_GROUP_RECORDS + group_id,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//
//                        try {
//                            JSONArray groupRecords =  new JSONArray(response);
//
//                            for(int i=0; i<groupRecords.length(); i++) {
//                                JSONObject groupRecordsObject = groupRecords.getJSONObject(i);
//
//
//                                String status = groupRecordsObject.getString("status");
//                                int count = groupRecordsObject.getInt("count");
//                                int total = groupRecordsObject.getInt("total");
//
//
//                            }
//
//
//
//
//                        } catch (JSONException e){
//                            e.printStackTrace();
//                        }
//
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(getApplicationContext(), "Wrong IP entered", Toast.LENGTH_LONG).show();
//
//                    }
//                });
//
//
//
//        Volley.newRequestQueue(this).add(stringRequest);
//    }
}
