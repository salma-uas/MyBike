package com.example.motorbikeapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class BookingPage extends AppCompatActivity {
    ImageView imageView;
    Button btnCompleted,mConfirm,btnCancel, btnArrived, btnPayment, btnFeedback;
    Spinner spinner, spinner1;
    TextView price, text;
    ArrayAdapter<CharSequence> adapter, adapter1;
    ProgressDialog progressDialog;

    int destination,location;
    String destination_point, location_point;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking_page);
        spinner = (Spinner) findViewById(R.id.spinner);
        spinner1 = (Spinner) findViewById(R.id.spinner1);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setTitle("Make Booking");

        if (SharedPrefManager.getInstance(BookingPage.this).isBooked()){
            finish();
            startActivity(new Intent(BookingPage.this, BookingPageContinue.class));
        }

        price = findViewById(R.id.price);
        adapter = ArrayAdapter.createFromResource(this, R.array.SelectDestination_names, android.R.layout.simple_spinner_item);
        adapter1 = ArrayAdapter.createFromResource(this, R.array.SelectLocation_names, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner1.setAdapter(adapter1);
        mConfirm = (Button) findViewById(R.id.btnConfirm);
        btnCancel = (Button) findViewById(R.id.btnCancel);
        btnArrived = (Button) findViewById(R.id.btnArrived);
//        btnCompleted = (Button) findViewById(R.id.btnCompleted);
//        btnPayment = (Button) findViewById(R.id.btnPayment);
//        btnFeedback = (Button) findViewById(R.id.btnFeedback);



//        btnCancel.setVisibility(View.INVISIBLE);
//        btnArrived.setVisibility(View.INVISIBLE);
//        btnCompleted.setVisibility(View.INVISIBLE);


        text = findViewById(R.id.text);



        mConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                makeBooking();
//                text.setText("Driver is on the way");
//                btnCancel.setVisibility(View.VISIBLE);
//                btnArrived.setVisibility(View.VISIBLE);
//                mConfirm.setVisibility(View.INVISIBLE);



            }
        });

//        btnCancel.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////                Intent registerIntent = new Intent(BookingPage.this, BookingPageContinue.class
////                );
////                startActivity(registerIntent);
//                text.setText("Cancel Booking within 2 minute of book");
//                btnCancel.setVisibility(View.INVISIBLE);
//                btnCompleted.setVisibility(View.INVISIBLE);
//                btnArrived.setVisibility(View.INVISIBLE);
//
//                mConfirm.setVisibility(View.VISIBLE);
//
//            }
//        });

//        btnArrived.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////                Intent registerIntent = new Intent(BookingPage.this, BookingPageContinue.class
////                );
////                startActivity(registerIntent);
//                text.setText("Driver has arrived");
//                btnArrived.setVisibility(View.INVISIBLE);
//                btnCompleted.setVisibility(View.VISIBLE);
//
//            }
//        });
//
//        btnCompleted.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////
//                text.setText("You reached your destination");
//                btnCompleted.setVisibility(View.INVISIBLE);
//                btnCancel.setVisibility(View.INVISIBLE);
//                btnFeedback.setVisibility(View.VISIBLE);
//                btnPayment.setVisibility(View.VISIBLE);
//
//            }
//        });



        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {

                location = spinner1.getSelectedItemPosition();
                destination = spinner.getSelectedItemPosition();

//                price.setText(String.valueOf(location));

                if (location == 0 && destination == 0) {
                    price.setText("RM8");
                } else if (location == 0 && destination == 1) {
                    price.setText("RM13");
                } else if (location == 0 && destination == 2) {
                    price.setText("RM13");
                } else if (location == 0 && destination == 3) {
                    price.setText("RM16");
                } else if (location == 0 && destination == 4) {
                    price.setText("RM5");
                } else if (location == 0 && destination == 5) {
                    price.setText("RM18");
                } else if (location == 0 && destination == 6) {
                    price.setText("RM17");
                } else if (location == 0 && destination == 7) {
                    price.setText("RM9");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });

        spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {

                location = spinner1.getSelectedItemPosition();
                destination = spinner.getSelectedItemPosition();
                if (location == 0 && destination == 0) {
                    price.setText("RM8");
                } else if (location == 0 && destination == 1) {
                    price.setText("RM13");
                } else if (location == 0 && destination == 2) {
                    price.setText("RM13");
                } else if (location == 0 && destination == 3) {
                    price.setText("RM16");
                } else if (location == 0 && destination == 4) {
                    price.setText("RM5");
                } else if (location == 0 && destination == 5) {
                    price.setText("RM18");
                } else if (location == 0 && destination == 6) {
                    price.setText("RM17");
                } else if (location == 0 && destination == 7) {
                    price.setText("RM9");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });


    }


    private void makeBooking() {

        SharedPrefManager sharedPrefManager = SharedPrefManager.getInstance(this);

        final int user_id = sharedPrefManager.getID();

        final String location_value = spinner1.getSelectedItem().toString();
        final String destination_value = spinner.getSelectedItem().toString();
        final String price_value = price.getText().toString().trim();

//        progressDialog.setMessage("Registering user......");
//        progressDialog.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_MAKE_BOOKING,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            if (!jsonObject.getBoolean("error")) {

                                SharedPrefManager.getInstance(getApplicationContext())
                                        .currentBooking(jsonObject.getInt("booking_id"),location_value,destination_value,"pending", user_id, 0,price_value );


                                Toast.makeText(getApplicationContext(), "Booking Successful", Toast.LENGTH_LONG).show();
                                finish();
                                Intent mainPage = new Intent(BookingPage.this, BookingPageContinue.class);
                                startActivity(mainPage);

                            } else {
                                Toast.makeText(getApplicationContext(), jsonObject.getString("message"), Toast.LENGTH_LONG).show();

                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getApplicationContext(), "Wrong IP entered", Toast.LENGTH_LONG).show();

                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();

                params.put("location", location_value);
                params.put("destination", destination_value);
                params.put("status", "pending");
                params.put("passenger_id", String.valueOf(user_id));
                params.put("price", price_value);

                return params;
            }
        };


        Volley.newRequestQueue(this).add(stringRequest);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }



}